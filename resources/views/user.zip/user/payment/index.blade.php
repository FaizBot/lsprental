@extends('layout-admin')

@section('content')
<div class="container-xxl">
    <h4 class="fw-bold mb-4">Daftar Pembayaran</h4>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>ID Rental</th>
                <th>Metode</th>
                <th>Jumlah</th>
                <th>Status</th>
                <th>Tanggal</th>
            </tr>
        </thead>
        <tbody>
            @foreach($payments as $payment)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>#{{ $payment->rental_id }}</td>
                <td>{{ ucfirst($payment->metode_pembayaran) }}</td>
                <td>Rp {{ number_format($payment->jumlah,0,',','.') }}</td>
                <td><span class="badge bg-info">{{ $payment->status }}</span></td>
                <td>{{ $payment->tanggal_bayar }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
