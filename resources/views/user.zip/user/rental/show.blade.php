@extends('layout-admin')

@section('content')
<div class="container-xxl">
    <h4 class="fw-bold mb-4">Detail Rental #{{ $rental->id }}</h4>

    <div class="card mb-4">
        <div class="card-body">
            <p><strong>Penyewa:</strong> {{ $rental->user->name ?? '-' }}</p>
            <p><strong>Mobil:</strong> {{ $rental->mobil->nama_mobil ?? '-' }}</p>
            <p><strong>Tanggal Mulai:</strong> {{ $rental->tanggal_mulai }}</p>
            <p><strong>Tanggal Selesai:</strong> {{ $rental->tanggal_selesai }}</p>
            <p><strong>Total Harga:</strong> Rp {{ number_format($rental->total_harga,0,',','.') }}</p>
            <p><strong>Status:</strong> 
                <span class="badge bg-info">{{ ucfirst($rental->status) }}</span>
            </p>
        </div>
    </div>

    <h5 class="fw-bold mb-3">Pembayaran</h5>
    @if($rental->payment)
        <div class="card mb-4">
            <div class="card-body">
                <p><strong>Metode:</strong> {{ ucfirst($rental->payment->metode_pembayaran) }}</p>
                <p><strong>Jumlah:</strong> Rp {{ number_format($rental->payment->jumlah,0,',','.') }}</p>
                <p><strong>Status:</strong> 
                    <span class="badge bg-success">{{ ucfirst($rental->payment->status) }}</span>
                </p>
                <p><strong>Tanggal Bayar:</strong> {{ $rental->payment->created_at->format('d/m/Y H:i') }}</p>

                @if($rental->payment->bukti_pembayaran)
                    <p><strong>Bukti Pembayaran:</strong></p>
                    <img src="{{ asset('storage/'.$rental->payment->bukti_pembayaran) }}" 
                         alt="Bukti Pembayaran" class="img-thumbnail" width="300">
                @endif
            </div>
        </div>
    @else
        <div class="alert alert-warning">
            Belum ada pembayaran.
        </div>
        <a href="{{ route('admin.payment.create', $rental->id) }}" class="btn btn-success">Tambah Pembayaran</a>
    @endif

    <a href="{{ route('admin.rental') }}" class="btn btn-secondary mt-3">Kembali</a>
</div>
@endsection
